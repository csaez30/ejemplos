package conectar;

import java.sql.*;
import javax.swing.JOptionPane;


public class conectar     
{

   
   
    
    public static void main(String[] args)
   {
      Connection conn = null;
      ResultSet rs=null;
       PreparedStatement ps = null;

      try{
         Class.forName("org.mariadb.jdbc.Driver").newInstance();
         conn = DriverManager.getConnection ("jdbc:mysql://localhost/agenda", "root", "");
          System.out.println("Conexion exitosa!!!");
          
          String query = "INSERT INTO persona (nombre, domicilio) VALUES ('Martin', 'San Martin')";
          
          ps = conn.prepareStatement(query);
          ps.executeUpdate(query); //no necesito asignar porque es insert
                 
          ps = conn.prepareStatement("SELECT * FROM persona");
          
           
            rs = ps.executeQuery();
 
            if (!rs.next())
                System.out.println("no hay registros");
            else do {
                JOptionPane.showMessageDialog(null, rs.getString("nombre")+" "+rs.getString("domicilio") );
                //System.out.println(rs.getString("nombre")+" "+rs.getString("domicilio") );
             
            } while (rs.next());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
      
      
      
      
      
      
      if(conn != null){
			try{
                        rs.close();
			conn.close();
			}
			catch(SQLException ee){
				System.err.println("No puede cerrar la conección");
			}
			System.out.println("Database connection terminated");
            }
  }
}  
